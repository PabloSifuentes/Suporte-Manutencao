import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

    GerenciamentoEleicao eleicao = new GerenciamentoEleicao();
    Scanner entradaDeVoto = new Scanner(System.in);
    int eleitores = 50;

    // Loop para coletar os votos de 50 eleitores
        Scanner scanner = null;
        for(int i = 0; i < eleitores; i++) {
        System.out.println("Eleitor " + (i + 1) + ":");

        // Informar turma
        System.out.println("Informe a sua turma (1 - Primeiro, 2 - Segundo, 3 - Terceiro ano): ");
        int turma = scanner.nextInt();
        while (turma < 1 || turma > 3) {
            System.out.println("Turma inválida. Informe a turma correta (1, 2 ou 3):");
            turma = scanner.nextInt();
        }

        // Informar voto
        System.out.println("Informe o número da chapa que deseja votar (1 a 6) ou 0 (Nulo) ou 10 (Branco): ");
        int voto = scanner.nextInt();
        while (voto != 0 && voto != 10 && (voto < 1 || voto > 6)) {
            System.out.println("Voto inválido. Informe o número correto. ");
        voto = scanner.nextInt();
        }

        // Contabilizar voto
        eleicao.votar(voto, turma);
    }
    // Mostrar os resultados ao final
        eleicao.mostrarResultados();
        scanner.close();
    }
}